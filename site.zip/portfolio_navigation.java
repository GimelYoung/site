function toggle_visibility(logos) {
	var e = document.getElementById(flyers, instructional, business, websites, misc);
	if(e.style.display == 'none')
	e.style.display = 'block';
	else
	e.style.display = 'none';
}
